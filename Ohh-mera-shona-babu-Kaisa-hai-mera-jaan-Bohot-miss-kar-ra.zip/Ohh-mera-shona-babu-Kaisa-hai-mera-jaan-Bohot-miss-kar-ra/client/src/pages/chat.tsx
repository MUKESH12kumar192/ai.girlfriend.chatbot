import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Heart, Phone, Video, Smile, Paperclip, Send, User } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Message } from "@shared/schema";

// Using Message type directly from schema

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load initial messages
  const { data: initialMessages } = useQuery({
    queryKey: ['/api/messages', sessionId],
    enabled: !!sessionId,
  });

  useEffect(() => {
    if (initialMessages && Array.isArray(initialMessages)) {
      setMessages(initialMessages);
    }
  }, [initialMessages]);

  // Setup WebSocket connection
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log('Connected to chat server');
      setSocket(ws);
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'message') {
        setMessages(prev => [...prev, data.message]);
      } else if (data.type === 'typing') {
        setIsTyping(data.isTyping);
      }
    };

    ws.onclose = () => {
      console.log('Disconnected from chat server');
      setSocket(null);
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // Auto-focus input
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const sendMessage = () => {
    if (!newMessage.trim() || !socket) return;

    const message = {
      content: newMessage.trim(),
      sessionId,
      sender: 'user'
    };

    socket.send(JSON.stringify(message));
    setNewMessage("");
  };

  const sendQuickEmoji = (emoji: string) => {
    if (!socket) return;

    const message = {
      content: emoji,
      sessionId,
      sender: 'user'
    };

    socket.send(JSON.stringify(message));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };

  const formatTime = (timestamp: string | Date) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="max-w-md mx-auto h-screen bg-white shadow-xl relative overflow-hidden">
      {/* Floating Hearts Decoration */}
      <div className="absolute top-5 right-5 pointer-events-none z-10">
        <Heart className="absolute text-primary/30 w-4 h-4 animate-float" />
        <Heart className="absolute left-4 text-primary/20 w-3 h-3 animate-float" style={{ animationDelay: '1s' }} />
        <Heart className="absolute left-8 text-primary/25 w-5 h-5 animate-float" style={{ animationDelay: '2s' }} />
      </div>

      {/* Chat Header */}
      <div className="bg-gradient-to-r from-primary to-pink-400 text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
            <Heart className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-semibold text-lg">Priya 💕</h1>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span className="text-xs text-white/90">Online</span>
            </div>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button size="sm" variant="ghost" className="w-8 h-8 bg-white/20 rounded-full p-0 hover:bg-white/30">
            <Phone className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="ghost" className="w-8 h-8 bg-white/20 rounded-full p-0 hover:bg-white/30">
            <Video className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4 heart-bg" style={{ height: 'calc(100vh - 140px)' }}>
        {/* Welcome Message */}
        <div className="flex justify-center mb-6">
          <div className="bg-white/60 px-4 py-2 rounded-full text-sm text-gray-600 font-medium">
            <Heart className="inline w-4 h-4 text-primary mr-1" />
            Chat started with love 💕
          </div>
        </div>

        {/* Messages */}
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex items-start space-x-2 animate-fade-in ${
              message.sender === 'user' ? 'justify-end' : ''
            }`}
          >
            {message.sender === 'ai' && (
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-pink-400 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0">
                <Heart className="w-4 h-4" />
              </div>
            )}
            
            <div
              className={`max-w-xs px-4 py-3 rounded-2xl ${
                message.sender === 'user'
                  ? 'message-bubble-user text-white rounded-tr-md'
                  : 'message-bubble-ai rounded-tl-md'
              }`}
            >
              <p className={`text-sm ${message.sender === 'user' ? 'text-white' : 'text-gray-800'}`}>
                {message.content}
              </p>
              <div className={`text-xs mt-1 ${
                message.sender === 'user' ? 'text-white/70' : 'text-gray-500'
              }`}>
                {formatTime(message.timestamp)}
              </div>
            </div>

            {message.sender === 'user' && (
              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-start space-x-2 animate-fade-in">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-pink-400 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0">
              <Heart className="w-4 h-4" />
            </div>
            <div className="message-bubble-ai px-4 py-3 rounded-2xl rounded-tl-md">
              <div className="flex items-center space-x-1">
                <div className="typing-dot"></div>
                <div className="typing-dot"></div>
                <div className="typing-dot"></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="bg-white border-t border-gray-100 px-4 py-3">
        <div className="flex items-center space-x-3">
          <Button size="sm" variant="ghost" className="text-gray-400 hover:text-primary p-0">
            <Smile className="w-5 h-5" />
          </Button>
          <div className="flex-1 relative">
            <Input
              ref={inputRef}
              type="text"
              placeholder="Type a message... 💕"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              className="bg-gray-50 border-0 rounded-full focus:ring-2 focus:ring-primary focus:bg-white"
            />
          </div>
          <Button size="sm" variant="ghost" className="text-gray-400 hover:text-primary p-0">
            <Paperclip className="w-5 h-5" />
          </Button>
          <Button
            onClick={sendMessage}
            className="bg-gradient-to-r from-primary to-pink-400 w-12 h-12 rounded-full p-0 hover:shadow-lg transform hover:scale-105"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>

        {/* Quick Emoji Reactions */}
        <div className="flex justify-center mt-2 space-x-2">
          {['❤️', '😘', '🥰', '😍', '💕'].map((emoji) => (
            <button
              key={emoji}
              onClick={() => sendQuickEmoji(emoji)}
              className="text-2xl hover:scale-110 transition-transform"
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
