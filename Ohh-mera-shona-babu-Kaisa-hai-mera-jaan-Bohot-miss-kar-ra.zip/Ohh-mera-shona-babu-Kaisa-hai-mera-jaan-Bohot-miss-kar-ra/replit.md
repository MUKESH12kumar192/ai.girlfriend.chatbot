# Chat Application with AI Integration

## Overview

This is a full-stack real-time chat application built with React, Express.js, and PostgreSQL. The application features real-time messaging through WebSockets and integrates with OpenAI's GPT-4 for AI-powered responses. The frontend uses modern React with TypeScript and shadcn/ui components, while the backend provides REST APIs and WebSocket support for live chat functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Bundler**: Vite for fast development and optimized builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Communication**: WebSocket client for live chat

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Real-time**: WebSocket server using 'ws' library
- **API Design**: RESTful endpoints for chat history
- **Development**: tsx for TypeScript execution in development

### Database & ORM
- **Database**: PostgreSQL (configured via DATABASE_URL)
- **ORM**: Drizzle ORM with Neon Database serverless driver
- **Schema Management**: Drizzle Kit for migrations
- **Current Storage**: In-memory storage for development (MemStorage class)

## Key Components

### Chat System
- **Real-time messaging**: WebSocket-based chat with typing indicators
- **Message persistence**: Database storage for chat history
- **Session management**: Unique session IDs for conversation isolation
- **AI integration**: OpenAI GPT-4 responses to user messages

### Frontend Components
- **Chat Interface**: Main chat page with message display and input
- **UI Components**: Comprehensive shadcn/ui component library
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Toast Notifications**: User feedback system

### Backend Services
- **WebSocket Handler**: Real-time message broadcasting
- **REST API**: Chat history retrieval
- **Storage Interface**: Abstracted storage layer (IStorage)
- **OpenAI Integration**: AI response generation

## Data Flow

1. **User Message Flow**:
   - User types message in frontend input
   - Message sent via WebSocket to server
   - Server validates and stores message in database
   - Server broadcasts message to all connected clients
   - Server sends message to OpenAI API for AI response
   - AI response stored and broadcast to clients

2. **Chat History Flow**:
   - Frontend requests chat history via REST API
   - Server queries database for session messages
   - Messages returned and displayed in chat interface

3. **Real-time Updates**:
   - WebSocket connection established on page load
   - Typing indicators and message updates broadcast in real-time
   - Connection state managed with auto-reconnection

## External Dependencies

### AI Services
- **OpenAI API**: GPT-4 integration for intelligent responses
- **Configuration**: API key via environment variables

### Database
- **Neon Database**: Serverless PostgreSQL provider
- **Connection**: Via DATABASE_URL environment variable
- **Migration**: Drizzle Kit for schema management

### UI Framework
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling framework
- **Lucide Icons**: Icon library for UI elements

## Deployment Strategy

### Development
- **Frontend**: Vite dev server with HMR
- **Backend**: tsx with automatic TypeScript compilation
- **Database**: Drizzle push for schema synchronization
- **Environment**: NODE_ENV=development

### Production Build
- **Frontend**: Static build output to dist/public
- **Backend**: esbuild bundling to dist/index.js
- **Serving**: Express serves static files and API routes
- **Database**: Production PostgreSQL via DATABASE_URL

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string
- **OPENAI_API_KEY**: OpenAI API authentication
- **NODE_ENV**: Environment mode (development/production)

### Current Limitations
- In-memory storage in development (will need PostgreSQL setup)
- OpenAI API key defaults to "default_key" if not configured
- WebSocket connection assumes same-origin deployment